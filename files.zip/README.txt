habitly app: hosting guide

files: index.html, manifest.webmanifest, sw.js, icon-192.png, icon-512.png, icon-maskable-512.png
keep all files together in the same folder.

1) host the folder (free, https is required for installing):
 - netlify: go to app.netlify.com/drop and drag the habitly-app folder in. done.
 - github pages: create a repo, upload these files, then settings > pages > deploy from branch (main, root).
 - cloudflare pages: create a project and upload the folder directly.

2) install it:
 - desktop chrome or edge: open your site, click the install icon in the address bar.
 - iphone: open in safari, tap share, then add to home screen.
 - android: open in chrome, menu, then install app.

3) your data:
 - data is saved per browser and per address. the installed app starts empty.
 - on your old copy: profile > export backup. in the new app: profile > import backup.

notes:
 - after you change index.html, change V='habitly-v1' in sw.js to v2 so installed copies update.
 - the ai buttons only appear on claude.ai and stay hidden in the installed app.
 - event reminders work while the app is open.
 - testing locally: run "python3 -m http.server" in this folder and open http://localhost:8000 (service workers don't run from file://).
